//#include "minCircle.h"
Circle welzl(Point **&P, vector<Point> R, int size);

// implement
Circle findMinCircle(Point **&points, int size) {
    vector<Point> R;
    return welzl(points, R, size);
}

Circle trivialCircle(vector<Point> R);

bool isInside(Circle &D, Point &p) {
    float x = p.x, y = p.y, circle_x = D.center.x, circle_y = D.center.y, rad = D.radius;
    // Compare radius of circle with distance
    // of its center from given point
    if ((x - circle_x) * (x - circle_x) +
        (y - circle_y) * (y - circle_y) <= rad * rad)
        return true;
    else
        return false;
}

Circle welzl(Point **&points, vector<Point> R, int size) {
    if (size == 0 || R.size() == 3) {
        return trivialCircle(R);
    }
    Point p = *points[size - 1];
    Circle D = welzl(points, R, (size - 1));
    if (isInside(D, p)) { return D; }
    R.push_back(p);
    return welzl(points, R, size - 1);;
}

Point findMiddle(Point &p1, Point &p2) {
    return {(p1.x + p2.x) / 2, (p1.y + p2.y) / 2};
}

float findDistance(Point &p1, Point &p2) {
    float xDiffPow = pow(p1.x - p2.x, 2);
    float yDiffPow = pow(p1.y - p2.y, 2);
    return sqrt(xDiffPow + yDiffPow);
}

Circle corectCircle3points(Point &p1, Point &p2, Point &p3) {
    float diffx2x1 = p2.x - p1.x;
    float diffy2y1 = p2.y - p1.y;
    float diffx3x1 = p3.x - p1.x;
    float diffy3y1 = p3.y - p1.y;
    //
    float powDiffxy21 = pow(diffx2x1, 2) + pow(diffy2y1, 2);
    float powDiffxy31 = pow(diffx3x1, 2) + pow(diffy3y1, 2);
    float mulxy31 = (diffx2x1 * diffy3y1) - (diffy2y1 * diffx3x1);
    Point findCircle = Point((diffy3y1 * powDiffxy21 - diffy2y1 * powDiffxy31) / (2 * mulxy31),
                             (diffx2x1 * powDiffxy31 - diffx3x1 * powDiffxy21) / (2 * mulxy31));
    findCircle.x = findCircle.x + p1.x;
    findCircle.y = findCircle.y + p1.y;

    return {findCircle, findDistance(findCircle, p1)};
}

Circle trivialCircle(vector<Point> R) {
    int size = R.size();
    switch (size) {
        case 1:
            return {R.at(0), 0};
        case 2:
            return {findMiddle(R.at(0), R.at(1)), findDistance(R.at(0), R.at(1)) / 2};
        case 3:
            return corectCircle3points(R.at(0), R.at(1), R.at(2));
        default:
            return {{0, 0}, 0};
    }
}