const fs = require("fs");
const express=require("express")
var {execFile} =require("child_process")
const fileUpload=require("express-fileupload")

const webApp=express()
webApp.use(express.urlencoded({
    extended: false
}))
webApp.use(fileUpload())
var viewPath='../view'
webApp.use(express.static(viewPath))

webApp.get('/',(req,res)=>{
    var htmlFile='./index.html'
    res.sendFile(htmlFile)
})
var detectPath='/detect'
webApp.post(detectPath,(req,res)=>{
    //push the files from the request
    var trainF=req.files.train_file
    var tesFile=req.files.test_file
    var model='../model/'
    var trPath= model+trainF.name
    var tesPath= model+tesFile.name

    //checking for errors
    trainF.mv(trPath, (error) => {
        if (error) {
            throw error
        }
    })
    tesFile.mv(tesPath, (error) => {
        if (error) {
            throw error
        }
    })
    var pathExec=null
     //run the regression algorithm
    if(req.body.algorithm == 'regression_algo'){
        var path='../model/Regression_algo.exe'
        pathExec=execFile(path,[trPath,tesPath],(error,stdout,stderror)=>{
            //callback for an erroror check
            if(error){
                throw error
            } else{
                res.write(stdout)
            res.end()
        }
        })
    }
     // run the hybrid algorithm
    if(req.body.algorithm == 'hybrid_algo'){
        var path2='../model/Hybrid_algo.exe'
        pathExec=execFile(path2,[trPath,tesPath],(error,stdout,stderror)=>{
            //exception catch if the model failed
            if(error){
                throw error
            } else{
            res.write(stdout)
            res.end()
        }
        })
    }
})
webApp.listen(8080,()=>console.log("listening on port 8080"));